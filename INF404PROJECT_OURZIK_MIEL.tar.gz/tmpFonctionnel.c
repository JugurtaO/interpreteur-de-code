#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "ast_construction.h"
#include "ast_parcours.h"
#include "analyse_syntaxique.h"
// #include "table_symboles.h"

int analyser(char *nom_fichier, Ast *arbre)
{

  demarrer(nom_fichier);

  init_table();

  int err = 0;

  err = Rec_pgm(arbre);

  if (lexeme_courant().nature != FIN_SEQUENCE)
  {
    err = 1;
    printf("Err final = %d\n", err);
  }

  if (err == 0)
  {
    printf("Programme correcte ..\n");

    return 0;
  }

  else
  {
    printf("Programme incorrecte !! ..\n");
    free_table();
    return 1;
  }
}

/*------------------------------------ récursive functions ------------------------------------------*/
/**************************Ici la grammaire de notre programme *******************************/
/***************************************************************************************************/
int Rec_eag(Ast *A)
{
 

  printf("inside eag : \n");
  int err = Rec_seq_terme(A);
  printf("inside eag after seq_terme:err = %d \n", err);
  if (err == 1)
    return 1;
  else
    return 0;
}
/********/
int Rec_seq_terme(Ast *A)
{
  Ast A1;
  printf("inside seq_terme : \n");

  int err = Rec_terme(&A1);
  printf("inside seq_terme after terme :err=%d \n", err);
  if (err == 1)
  {
    printf("Erreur in Rec_terme: \n");
    return 1;
  }
  err = Rec_suite_seq_terme(A1, A);
  printf("inside seq_terme after suite_seq_terme : err=%d\n", err);
  if (err == 1)
  {
    printf("Erreur in Rec_suite_seq_terme : \n");
    return 1;
  }
  return 0;
}
/********/
int Rec_suite_seq_terme(Ast Ag, Ast *A)
{
  Ast Ad;
  Ast A1;
  TypeOperateur Op;

  printf("inside suite_seq_terme : \n");
  switch (lexeme_courant().nature)
  {
  case PLUS:
  case MOINS:
    int err = Rec_op1(&Op);
    printf("inside suite_seq_terme after OP1: err=%d\n", err);
    if (err != 1)
    {
      err = Rec_terme(&Ad);
      printf("inside suite_seq_terme after terme:err=%d \n", err);
      if (err == 1)
      {
        printf("Erreur in Rec_terme l,53 : \n");
        return 1;
      }

      printf("************\n");

      printf("\n");

      printf("\n");
      printf("************\n");
      A1 = creer_operation(Op, Ag, Ad);
      AfficherAST(A1);
      err = Rec_suite_seq_terme(A1, A);
      printf("inside suite_seq_terme after suite_seq_terme :err=%d \n", err);
      if (err == 1)
      {
        printf("Erreur in Rec_suite_seq_terme l,60 : \n");
        return 1;
      }

      return 0;
    }

    break;

  default:
    printf("J'ai lu epsilone : \n");
    *A = Ag;
    break;
  }
}
/********/
int Rec_terme(Ast *A)
{
  printf("inside terme : \n");
  int err = Rec_seq_facteur(A);
  printf("inside terme after seq_facteur :err= %d \n", err);
  if (err == 1)
    return 1;
  else
    return 0;
}
/********/
int Rec_seq_facteur(Ast *A)
{
  Ast A1;
  printf("inside seq_facteur : \n");
  int err;
  err = Rec_facteur(&A1);
  printf("inside seq_facteur after facteur:err= %d \n", err);

  if (err == 1)
  {
    printf("Erreur in Rec_facteur l,83 : \n");
    return err;
  }
  err = Rec_suite_seq_facteur(A1, A);
  printf("inside seq_facteur after suite_seq_facteur: err=%d \n", err);
  if (err == 1)
  {
    printf("Erreur in Rec_suite_seq_facteur l,90 : \n");
    return 1;
  }
  return 0;
}
/********/
int Rec_suite_seq_facteur(Ast Ag, Ast *A)
{
  Ast Ad;
  Ast A1;
  TypeOperateur Op;
  printf("inside suite_seq_facteur : \n");
  int err;
  err = Rec_op2(&Op);
  printf("inside suite_seq_facteur after OP2:err=%d\n", err);
  if (err != 1)
  {
    err = Rec_facteur(&Ad);

    printf("inside suite_seq_facteur after facteur :err=%d\n", err);
    if (err == 1)
    {
      printf("Erreur in Rec_facteur in suite_seq_facteur : \n");
      return 1;
    }
    A1 = creer_operation(Op, Ag, Ad);
    AfficherAST(A1);
    printf("\n");
    err = Rec_suite_seq_facteur(A1, A);
    printf("inside suite_seq_facteur after_suite_seq_facteur :err=%d \n", err);
    if (err == 1)
    {
      printf("Erreur in Rec_suite_seq_facteur l,115 : \n");
      return 1;
    }
    return 0;
  }
  printf("j'ai lu epsilone\n");
  *A = Ag;
}
/********/

int Rec_facteur(Ast *A)
{
  int value;

  printf("inside Facteur : \n");
  afficher(lexeme_courant());
  printf("\n");
  switch (lexeme_courant().nature)
  {
  case ENTIER:
    *A = creer_valeur(lexeme_courant().valeur);
    avancer();
    printf("Case entier\n");

    break;
  case PARO:

    avancer();

    int err = Rec_eag(A);
    printf("inside Facteur after eag :err=%d \n", err);
    if (err == 1)
    {
      printf("Erreur in Rec_eag l,144 : \n");
      return 1;
    }

    if (lexeme_courant().nature == PARF)
    {
      avancer();
    }

    else
    {
      printf("Error from not PARF\n");
      return 1;
    }
    break;
  case IDF:

    if (field_IsIn(lexeme_courant().chaine) != 1)
    {
      value = search_value(lexeme_courant().chaine);
      printf("la valeur retrouvée dans la table est %s = %d\n ",lexeme_courant().chaine,value);
      *A = creer_valeur(value);
      avancer();     //added now 
    }
    else
    {
      printf("Variable <%s>  non initialisée auapravant!!!\n", lexeme_courant().chaine);
      return 1;
    }
    return 0;
    break;

    // afficher(lexeme_courant());
    // err = Rec_seq_affectation(A);
    // printf("inside Facteur after affectation :err=%d \n", err);
    // if (err == 1)
    // {
    //   printf("Erreur in Rec_affectation l,235 : \n");
    //   return 1;
    // }
    // break;

  default:
    printf("error from default\n");
    return 1;
    break;
  }

  return 0;
}
/********/
int Rec_op1(TypeOperateur *Op)
{
  printf("inside OP1 : \n");
  afficher(lexeme_courant());
  printf("\n");
  switch (lexeme_courant().nature)
  {
  case PLUS:
    *Op = N_PLUS;
    avancer();
    break;
  case MOINS:
    *Op = N_MOINS;
    avancer();
    break;

  default:
    return 1;
    break;
  }
}
/********/
int Rec_op2(TypeOperateur *Op)
{
  printf("inside OP2 : \n");
  switch (lexeme_courant().nature)
  {
  case MUL:
    *Op = N_MUL;
    avancer();
    break;
  case DIV:
    *Op = N_DIV;
    avancer();

    break;

  default:
    return 1;
    break;
  }
}

int Rec_seq_affectation(Ast *A)
{

  switch (lexeme_courant().nature)
  {
  case IDF:

    int err = Rec_affectation(A);
    printf("inside SEQ_AFFECTATION  after affectation :err=%d \n", err);
    if (err == 1)
    {
      printf("Erreur in Rec_affectation l,144 : \n");
      return 1;
    }

    err = Rec_seq_affectation(A);
    printf("inside seq_affectation  after affectation :err=%d \n", err);
    if (err == 1)
    {
      printf("Erreur in Rec_seq_affectation l,316 : \n");
      return 1;
    }
    return 0;
    break;

  default: // epsilon
    break;
  }
}

int Rec_affectation(Ast *A)
{
  printf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$1\n");
  Ast T;
  Ast Ag;
  Ast Ad;
  char name[128];
  int value;
  int err = 0;

  if (lexeme_courant().nature == IDF)
  {

    //********** on sauvegarde la chaine de l'identifiant pour l'insérer après.
    strcpy(name, lexeme_courant().chaine);
    avancer();

    /*******************code ajouté**/
    afficher(lexeme_courant());
    printf("\n");

    Ag = creer_idf(lexeme_courant().chaine);

    if (lexeme_courant().nature == EGAL)
      avancer();
    else
      return 1;

    err = Rec_eag(&Ad); // Ad contient l’AST de l’expression

    if (err == 1)
    {

      printf("Erreur in Rec_affectation after Rec_eag : \n");
      return 1;
    }
    // cree un noeud N_AFF de fils Ag et Ad

    *A = creer_aff(Ag, Ad);
  }
  else
    return 1;

  // if (lexeme_courant().nature == EGAL)
  // {
  //   avancer();
  //   afficher(lexeme_courant());
  //   printf("\n");
  // }
  // else
  //   return 1;

  // err = Rec_eag(&T);

  // if (err == 1)

  // {
  //   printf("Erreur in Rec__affectation after Rec_eag l,341 : \n");
  //   return 1;
  // }

  value = evaluation(Ad);

  printf("EVALUATION de %s  ====== :%d\n",name, value);
  insert_field(name, value);
  printf("INSERTED SUCCESSFULLY !!\n");

  if (lexeme_courant().nature == PVIRG)
    avancer();
  else
  {
    printf("Error from not PVIRG\n");
    return 1;
  }

  return 0;
}

int Rec_pgm(Ast *A)
{
  printf("inside rec_pgm \n");
  int err = Rec_seq_inst(A);
  if (err == 1)
    return 1;
  else
    return 0;
}

int Rec_seq_inst(Ast *A)
{
  printf("inside rec_seq_inst \n");
  Ast A1;
  int err = 0;
  err = Rec_inst(&A1);
  if (err == 1)
  {
    printf("Erreur in Rec_seq_inst after Rec_inst : \n");
    return 1;
  }

  err = Rec_suite_seq_inst(A1, A);
  if (err == 1)

  {
    printf("Erreur in Rec_seq_inst after Rec_suite_seq_inst : \n");
    return 1;
  }

  return 0;
}

int Rec_suite_seq_inst(Ast A1, Ast *A)
{
  printf("inside rec_suite_seq_inst \n");

  Ast A2;
  int err = 0;
  switch (lexeme_courant().nature)
  {
  case PVIRG:
    avancer();
    err = Rec_seq_inst(&A2);
    if (err == 1)
    {
      printf("Erreur in Rec_suite_seq_inst after Rec_seq_inst : \n");
      return 1;
    }

    // CREE UN NOEUD N_SEPINST DE FILS GAUCHE A1 & DE FILS DROIT A2
    *A = creer_seqinst(A1, A2);
    break;

  default:
    *A = A1;
    break;
  }

  return 0;
}

int Rec_inst(Ast *A)
{
  printf("inside rec_inst \n");
  Ast Ag;
  // Ast Ad;
  int err = 0;
  switch (lexeme_courant().nature)
  {
  case IDF: // cree un arbre gauche qui contient l’IDF Ag = creer_idf (LC().chaine)
    // afficher(lexeme_courant());
    // printf("\n");
    // Ag = creer_idf(lexeme_courant().chaine);
    // avancer();

    // if (lexeme_courant().nature == EGAL)
    //   avancer();
    // else
    //   return 1;

    // err = Rec_eag(&Ad); // Ad contient l’AST de l’expression

    // if (err == 1)
    // {
    //   printf("Erreur in Rec_inst after Rec_eag : \n");
    //   return 1;
    // }
    // // cree un noeud N_AFF de fils Ag et Ad
    // *A = creer_aff(Ag, Ad);

    err = Rec_seq_affectation(A);
    if (err == 1)
    {
      printf("Ouuups erreur dans REC_inst !!\n");
      return 1;
    }
    return 0;
    break;
  case PRINTF:
    avancer();
    if (lexeme_courant().nature == PARO)
      avancer();
    else
      return 1;

    if (lexeme_courant().nature == IDF)
    {
      Ag = creer_idf(lexeme_courant().chaine);
      avancer();
    }
    else
      return 1;

    // cree un noeud N_LIRE de fils gauche Ag
    *A = creer_ecrire(Ag);

    if (lexeme_courant().nature == PARF)
      avancer();
    else
      return 1;

    return 0;
    break;
  case SCANF:
    avancer();
    if (lexeme_courant().nature == PARO)
      avancer();
    else
      return 1;

    if (lexeme_courant().nature == IDF)
    {
      Ag = creer_idf(lexeme_courant().chaine);
      avancer();
    }
    else
      return 1;

    // cree un noeud N_LIRE de fils gauche Ag
    *A = creer_lire(Ag);

    if (lexeme_courant().nature == PARF)
      avancer();
    else
      return 1;

    return 0;
    break;

  default:

    if (lexeme_courant().nature != FIN_SEQUENCE)
    {
      printf("enter CASE DEFAULT Rec_inst\n ");
      return 1;
    }
    break;
  }
}