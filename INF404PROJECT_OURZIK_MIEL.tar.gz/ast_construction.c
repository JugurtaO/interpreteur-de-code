#include <stdlib.h>
#include <stdio.h> 
#include <string.h>
#include "type_ast.h"

Ast creer_operation(TypeOperateur opr , Ast opde_gauche , Ast opde_droit) 
{
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = OPERATION;
      expr->operateur = opr;
      if (opde_gauche == NULL || opde_droit == NULL) {
         printf("ERREUR_EXPRESSION\n") ;
	 exit(1) ;
      } else {
         expr->gauche = opde_gauche;
         expr->droite = opde_droit;
      } ;
      return expr ;
}

Ast creer_valeur(int val) { 
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = VALEUR;
      expr->valeur = val;
      return expr ;
}

Ast creer_idf(char * idf) { 
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = N_IDF;
      strcpy(expr->idf,idf) ;
      return expr ;
}
Ast creer_ecrire(Ast Ag){
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = N_PRINTF;
      expr->gauche=Ag;
      
      return expr ;
}

Ast creer_lire(Ast Ag){
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = N_SCANF;
      expr->gauche=Ag;
      
      return expr ;
}

Ast creer_aff(Ast Ag,Ast Ad){
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = N_EGAL;
      expr->gauche=Ag;
      expr->droite=Ad;
      return expr;

}
Ast creer_seqinst(Ast A1, Ast A2){
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = N_PVIRG;
      expr->gauche=A1;
      expr->droite=A2;
      return expr;
}

Ast creer_if(Ast Ag,Ast Ac, Ast Ad){
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = N_IF;
      expr->gauche=Ag;
      expr->central=Ac;
      expr->droite=Ad;
      return expr;

}

Ast creer_sup(Ast Ag,Ast Ad){
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = N_SUP;
      expr->gauche=Ag;
      expr->droite=Ad;
      return expr;

}
Ast creer_inf(Ast Ag,Ast Ad){
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = N_INF;
      expr->gauche=Ag;
      expr->droite=Ad;
      return expr;

}

Ast creer_egal(Ast Ag,Ast Ad){
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = N_EGALCOND;
      expr->gauche=Ag;
      expr->droite=Ad;
      return expr;

}
Ast creer_supegal(Ast A1,Ast A2){
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature =N_SUPEGAL;
      expr->gauche=A1;
      expr->droite=A2;
      return expr;
}
Ast creer_notegal(Ast A1,Ast A2){
       Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature =N_NOTEGAL;
      expr->gauche=A1;
      expr->droite=A2;
      return expr;
}
Ast creer_infegal(Ast A1,Ast A2){
       Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature =N_INFEGAL;
      expr->gauche=A1;
      expr->droite=A2;
      return expr;
}
Ast creer_while(Ast Ag,Ast  Ad){
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = N_WHILE;
      expr->gauche=Ag;
      expr->droite=Ad;
      return expr;

}
Ast creer_for(Ast Ag,Ast  Ad){
      Ast expr ;
      expr = (Ast) malloc (sizeof(NoeudAst));
      expr->nature = N_FOR;
      expr->gauche=Ag;
      expr->droite=Ad;
      return expr;

}

void free_AST(Ast A){
      if(A!=NULL){
            free(A->gauche);
            free(A->droite);
            free(A);
      }

}