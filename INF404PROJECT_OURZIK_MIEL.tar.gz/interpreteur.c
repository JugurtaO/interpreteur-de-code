#include "analyse_syntaxique.h"
#include "ast_parcours.h"
#include "ast_construction.h"
#include <stdlib.h>

#include "table_symboles.h"


int main(int argc,char**argv) {

     
   
    Ast A;

    if (argc!=2)
        printf("LAUNCH WITH : ./interpreteur <txt file name> \n");
        
    
    else{
        int err=analyser(argv[1],&A);
        if(err==1){
            printf("Impossible d'interpréter le programme , une erreur s'est produite !\n");
            return 0;
        }
       

      

        printf("---------AFFICHAGE DE L\'AST-----------\n");
        AfficherAST(A);
        printf("---------AFFICHAGE TERMINÉ------------- \n");

        
        printf("**Je commence l\'interpretation du programme**\n");
        

 
        interpretation_finale(A);
       
    
        print_table();
        free_table();
        free_AST(A);
       
    

      
        
       
        
    }
    return 0;
}



