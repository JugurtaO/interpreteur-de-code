#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "ast_construction.h"
#include "ast_parcours.h"
#include "analyse_syntaxique.h"

int analyser(char *nom_fichier, Ast *arbre)
{

  demarrer(nom_fichier);

  init_table();

  int err = 0;

  err = Rec_pgm(arbre);

  // printf("after pgm err= %d\n", err);
  printf("\n AST IS BUILT\n");

  if (lexeme_courant().nature != FIN_SEQUENCE)
  {
    err = 1;
    printf("Err final = %d\n", err);
  }

  if (err == 0)
  {
    printf("Programme correcte ..\n");
    printf("\n");

    return 0;
  }

  else
  {
    printf("Programme incorrecte !! ..\n");
    free_table();
    return 1;
  }
}

/*------------------------------------ récursive functions ------------------------------------------*/
/**************************Ici la grammaire de notre programme *******************************/
/***************************************************************************************************/
int Rec_eag(Ast *A)
{

  // printf("inside eag : \n");
  int err = Rec_seq_terme(A);
  // printf("inside eag after seq_terme:err = %d \n", err);
  if (err == 1)
    return 1;
  else
    return 0;
}
/********/
int Rec_seq_terme(Ast *A)
{
  Ast A1;
  // printf("inside seq_terme : \n");

  int err = Rec_terme(&A1);
  // printf("inside seq_terme after terme :err=%d \n", err);
  if (err == 1)
  {
    printf("Erreur in Rec_terme: \n");
    return 1;
  }
  err = Rec_suite_seq_terme(A1, A);
  // printf("inside seq_terme after suite_seq_terme : err=%d\n", err);
  if (err == 1)
  {
    printf("Erreur in Rec_suite_seq_terme : \n");
    return 1;
  }
  return 0;
}
/********/
int Rec_suite_seq_terme(Ast Ag, Ast *A)
{
  Ast Ad;
  Ast A1;
  TypeOperateur Op;

  // printf("inside suite_seq_terme : \n");
  switch (lexeme_courant().nature)
  {
  case PLUS:
  case MOINS:
    int err = Rec_op1(&Op);
    // printf("inside suite_seq_terme after OP1: err=%d\n", err);
    if (err != 1)
    {
      err = Rec_terme(&Ad);
      // printf("inside suite_seq_terme after terme:err=%d \n", err);
      if (err == 1)
      {
        printf("Erreur in Rec_terme l,53 : \n");
        return 1;
      }
      A1 = creer_operation(Op, Ag, Ad);
      // AfficherAST(A1);
      err = Rec_suite_seq_terme(A1, A);
      // printf("inside suite_seq_terme after suite_seq_terme :err=%d \n", err);
      if (err == 1)
      {
        printf("Erreur in Rec_suite_seq_terme l,60 : \n");
        return 1;
      }

      return 0;
    }

    break;

  default:
    // printf("J'ai lu epsilone : \n");
    *A = Ag;
    break;
  }
}
/********/
int Rec_terme(Ast *A)
{
  // printf("inside terme : \n");
  int err = Rec_seq_facteur(A);
  // printf("inside terme after seq_facteur :err= %d \n", err);
  if (err == 1)
    return 1;
  else
    return 0;
}
/********/
int Rec_seq_facteur(Ast *A)
{
  Ast A1;
  // printf("inside seq_facteur : \n");
  int err;
  err = Rec_facteur(&A1);
  // printf("inside seq_facteur after facteur:err= %d \n", err);

  if (err == 1)
  {
    printf("Erreur in Rec_facteur l,83 : \n");
    return err;
  }
  err = Rec_suite_seq_facteur(A1, A);
  // printf("inside seq_facteur after suite_seq_facteur: err=%d \n", err);
  if (err == 1)
  {
    printf("Erreur in Rec_suite_seq_facteur l,90 : \n");
    return 1;
  }
  return 0;
}
/********/
int Rec_suite_seq_facteur(Ast Ag, Ast *A)
{
  Ast Ad;
  Ast A1;
  TypeOperateur Op;
  // printf("inside suite_seq_facteur : \n");
  int err;
  err = Rec_op2(&Op);
  // printf("inside suite_seq_facteur after OP2:err=%d\n", err);
  if (err != 1)
  {
    err = Rec_facteur(&Ad);

    // printf("inside suite_seq_facteur after facteur :err=%d\n", err);
    if (err == 1)
    {
      printf("Erreur in Rec_facteur in suite_seq_facteur : \n");
      return 1;
    }
    A1 = creer_operation(Op, Ag, Ad);
    // AfficherAST(A1);
    // // printf("\n");
    err = Rec_suite_seq_facteur(A1, A);
    // printf("inside suite_seq_facteur after_suite_seq_facteur :err=%d \n", err);
    if (err == 1)
    {
      printf("Erreur in Rec_suite_seq_facteur l,115 : \n");
      return 1;
    }
    return 0;
  }
  // printf("j'ai lu epsilone\n");
  *A = Ag;
}
/********/

int Rec_facteur(Ast *A)
{
  // printf("inside Facteur : \n");
  // // afficher(lexeme_courant());
  // // printf("\n");
  switch (lexeme_courant().nature)
  {
  case ENTIER:
    *A = creer_valeur(lexeme_courant().valeur);
    avancer();
    // printf("Case entier\n");

    break;
  case PARO:

    avancer();

    int err = Rec_eag(A);
    // printf("inside Facteur after eag :err=%d \n", err);
    if (err == 1)
    {
      printf("Erreur in Rec_eag l,144 : \n");
      return 1;
    }

    if (lexeme_courant().nature == PARF)
    {
      avancer();
    }

    else
    {
      printf("Error from not PARF\n");
      return 1;
    }
    break;
  case IDF:

    if (field_IsIn(lexeme_courant().chaine) != 1)
    {
      *A = creer_idf(lexeme_courant().chaine);
      avancer(); // added now
    }
    else
    {
      printf("Variable <%s>  non initialisée auapravant!!!\n", lexeme_courant().chaine);
      return 1;
    }

    // avancer();
    return 0;
    break;

  default:
    printf("error from default\n");
    return 1;
    break;
  }

  return 0;
}
/********/
int Rec_op1(TypeOperateur *Op)
{
  // printf("inside OP1 : \n");
  // // afficher(lexeme_courant());
  // printf("\n");
  switch (lexeme_courant().nature)
  {
  case PLUS:
    *Op = N_PLUS;
    avancer();
    break;
  case MOINS:
    *Op = N_MOINS;
    avancer();
    break;

  default:
    return 1;
    break;
  }
}
/********/
int Rec_op2(TypeOperateur *Op)
{
  // printf("inside OP2 : \n");
  switch (lexeme_courant().nature)
  {
  case MUL:
    *Op = N_MUL;
    avancer();
    break;
  case DIV:
    *Op = N_DIV;
    avancer();

    break;

  default:
    return 1;
    break;
  }
}

int Rec_seq_affectation(Ast *A)
{

  switch (lexeme_courant().nature)
  {
  case IDF:

    int err = Rec_affectation(A);
    // printf("inside SEQ_AFFECTATION  after affectation :err=%d \n", err);
    if (err == 1)
    {
      printf("Erreur in Rec_affectation l,144 : \n");
      return 1;
    }

    err = Rec_seq_affectation(A);
    // printf("inside seq_affectation  after affectation :err=%d \n", err);
    if (err == 1)
    {
      printf("Erreur in Rec_seq_affectation l,316 : \n");
      return 1;
    }
    return 0;
    break;

  default: // epsilon
    break;
  }
}

int Rec_affectation(Ast *A)
{
  // printf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$1\n");
  Ast T;
  char name[128];
  int value;
  int err = 0;

  /*******************code ajouté**/

  if (lexeme_courant().nature == EGAL)
  {
    avancer();
    // // afficher(lexeme_courant());
    // printf("\n");
  }
  else
    return 1;

  err = Rec_eag(&T);

  if (err == 1)

  {
    printf("Erreur in Rec__affectation after Rec_eag l,341 : \n");
    return 1;
  }
  *A = T;

  return 0;
}

int Rec_pgm(Ast *A)
{
  // printf("rec_pgm(\n");
  int err = Rec_seq_inst(A);
  // printf(")\n");
  if (err == 1)
  {
    printf("error in seq_pgm after seq_inst\n");
    return 1;
  }
  else
    return 0;
}

int Rec_seq_inst(Ast *A)
{
  // printf("rec_seq_inst(\n");
  Ast A1;
  int err = 0;
  err = Rec_inst(&A1);
  // // printf(")\n");

  if (err == 1)
  {
    printf("Erreur in Rec_seq_inst after Rec_inst : \n");
    return 1;
  }

  err = Rec_suite_seq_inst(A1, A);
  // // printf(")\n");
  if (err == 1)

  {
    printf("Erreur in Rec_seq_inst after Rec_suite_seq_inst : \n");
    return 1;
  }

  return 0;
}

int Rec_suite_seq_inst(Ast A1, Ast *A)
{
  // printf("rec_suite_seq_inst( \n");

  Ast A2;
  int err = 0;

  switch (lexeme_courant().nature)
  {
  case PVIRG:
    avancer();
    err = Rec_seq_inst(&A2);
    // printf(")\n");
    if (err == 1)
    {
      printf("Erreur in Rec_suite_seq_inst after Rec_seq_inst : \n");
      return 1;
    }

    // CREE UN NOEUD N_SEPINST DE FILS GAUCHE A1 & DE FILS DROIT A2
    *A = creer_seqinst(A1, A2);
    break;

  default:
    //  printf("Default from suit_seq_inst ******\n");
    *A = A1;
    break;
  }

  return 0;
}

int Rec_inst(Ast *A)
{
  // printf("rec_inst( \n");
  Ast Ag;
  Ast Ad;
  Ast Ac;
  Ast Apg;
  Ast Apd;
  char name[128];
  char name2[128];
  int value;
  int err = 0;
  switch (lexeme_courant().nature)
  {
  case IDF: // cree un arbre gauche qui contient l’IDF Ag = creer_idf (LC().chaine)

    strcpy(name, lexeme_courant().chaine);

    // // afficher(lexeme_courant());
    // // printf("\n");
    Ag = creer_idf(lexeme_courant().chaine);
    avancer();

    err = Rec_affectation(&Ad);
    // // printf(")\n");
    if (err == 1)
    {
      printf("Erreur in Rec_inst after Rec_seq_affecctation : \n");
      return 1;
    }
    insert_field(name, 0);
    *A = creer_aff(Ag, Ad); // creer noeud affectation

    return 0;
    break;

  case PRINTF:
    avancer();
    if (lexeme_courant().nature == PARO)
      avancer();
    else
      return 1;

    err = Rec_eag(&Ag);
    // // printf(")\n");
    if (err != 0)
    {
      return 1;
    }
    // cree un noeud N_LIRE de fils gauche Ag
    *A = creer_ecrire(Ag);

    if (lexeme_courant().nature == PARF)
      avancer();
    else
      return 1;

    return 0;
    break;
  case SCANF:
    avancer();
    if (lexeme_courant().nature == PARO)
      avancer();
    else
      return 1;

    if (lexeme_courant().nature == IDF)
    {
      Ag = creer_idf(lexeme_courant().chaine);
      insert_field(lexeme_courant().chaine, 0);
      avancer();
    }
    else
      return 1;

    // cree un noeud N_LIRE de fils gauche Ag
    *A = creer_lire(Ag);

    if (lexeme_courant().nature == PARF)
      avancer();
    else
      return 1;

    return 0;
    break;

  case IF:
    // // afficher(lexeme_courant());
    avancer();
    // lire une parenthèse ouvrante
    if (lexeme_courant().nature == PARO)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;

    err = Rec_condition(&Ag);
    // // printf(")\n");
    if (err == 1)
    {
      printf("Erreur in Rec_inst after Rec_seq_inst dans case IF 1 : \n");
      return 1;
    }
    // lire une parenthèse fermante
    if (lexeme_courant().nature == PARF)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;

    if (lexeme_courant().nature == THEN)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;

    // lire une parenthèse ouvrante
    if (lexeme_courant().nature == ACCO)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;

    err = Rec_seq_inst(&Ac);
    // // printf(")\n");
    if (err == 1)
    {
      printf("Erreur in Rec_inst after Rec_seq_inst dans case IF 2 : \n");
      return 1;
    }
    // lire une parenthèse fermante
    if (lexeme_courant().nature == ACCF)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;

    if (lexeme_courant().nature != ELSE)
    {
      *A = creer_if(Ag, Ac, Ad);
      return 0;
    }

    else
    {
      // //  afficher(lexeme_courant());
      avancer();

      // lire une parenthèse ouvrante
      if (lexeme_courant().nature == ACCO)
      {
        // afficher(lexeme_courant());
        avancer();
      }
      else
        return 1;

      err = Rec_seq_inst(&Ad);
      // // printf(")\n");
      if (err == 1)
      {
        printf("Erreur in Rec_inst after Rec_seq_inst dans case IF 3 : \n");
        return 1;
      }
      // lire une parenthèse fermante
      if (lexeme_courant().nature == ACCF)
      {
        // afficher(lexeme_courant());
        avancer();
      }
      else
        return 1;

      *A = creer_if(Ag, Ac, Ad);

      return 0;
    }
    // on crée le noeud if avec ses trois fils gauche (condition) , central(then), droite(else)

    break;

  case WHILE:
    // printf("inside Rec_inst in WHILE \n");

    // // afficher(lexeme_courant());
    avancer();
    if (lexeme_courant().nature == PARO)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;

    err = Rec_condition(&Ag);
    // // printf(")\n");
    if (err == 1)
    {
      printf("Erreur in Rec_inst after Rec_seq_inst dans WHILE 1 : \n");
      return 1;
    }
    // lire une parenthèse fermante
    if (lexeme_courant().nature == PARF)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;

    // LIRE UNE ACCOLADE OUVRANTE
    if (lexeme_courant().nature == ACCO)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;

    err = Rec_seq_inst(&Ad);
    // // printf(")\n");
    if (err == 1)
    {
      printf("Erreur in Rec_inst after Rec_seq_inst dans WHILE 2: \n");
      return 1;
    }
    // lire une ACCOLADE fermante
    if (lexeme_courant().nature == ACCF)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;

    *A = creer_while(Ag, Ad);
    if (lexeme_courant().nature == PVIRG)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;
    break;
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  case FOR:
    // // afficher(lexeme_courant());
    avancer();
    if (lexeme_courant().nature == PARO)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    if (lexeme_courant().nature == IDF)
    {
      strcpy(name, lexeme_courant().chaine);
      // // afficher(lexeme_courant());
      // // printf("\n");
      Ag = creer_idf(lexeme_courant().chaine);
      avancer();
      err = Rec_affectation(&Ad);
      // // printf(")\n");
      if (err == 1)
      {
        printf("Erreur in Rec_inst after Rec_affecctation : \n");
        return 1;
      }
      insert_field(name, 0);
      Ag = creer_aff(Ag, Ad); // creer noeud affectation}
    }
    else
    {
      return 1;
    }
    if (lexeme_courant().nature == PVIRG)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    err = Rec_condition(&Ac);
    // // printf(")\n");
    if (err == 1)
    {
      printf("Erreur in Rec_inst after Rec_seq_inst dans WHILE 1 : \n");
      return 1;
    }
    if (lexeme_courant().nature == PVIRG)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    if (lexeme_courant().nature == IDF)
    {
      strcpy(name2, lexeme_courant().chaine);
      // // afficher(lexeme_courant());
      // printf("\n");
      Apg = creer_idf(lexeme_courant().chaine);
      avancer();
      err = Rec_affectation(&Apd);
      // // printf(")\n");
      if (err == 1)
      {
        printf("Erreur in Rec_inst after Rec_affecctation : \n");
        return 1;
      }
      insert_field(name2, 0);
      Apd = creer_aff(Apg, Apd); // creer noeud affectation}
      if (strcmp(name, name2) != 0)
      {
        printf("Error in for declaration is not use in incrementation");
        return 1;
      }
    }
    else
    {
      return 1;
    }
    if (lexeme_courant().nature == PARF)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;
    ////////////////////////////////////////////////////////////////////////////////////////////////
    if (lexeme_courant().nature == ACCO)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;
    err = Rec_seq_inst(&Apg);
    // // printf(")\n");
    if (err == 1)
    {
      printf("Erreur in Rec_inst after Rec_seq_inst dans WHILE 2: \n");
      return 1;
    }
    // lire une ACCOLADE fermante
    if (lexeme_courant().nature == ACCF)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;
    Ad = creer_seqinst(Apg, Apd);
    Ad = creer_while(Ac, Ad);
    *A = creer_for(Ag, Ad);
    if (lexeme_courant().nature == PVIRG)
    {
      // afficher(lexeme_courant());
      avancer();
    }
    else
      return 1;
    printf("j'ai lu for en entier");
    break;

  default:
    // // afficher(lexeme_courant());
    if (lexeme_courant().nature != FIN_SEQUENCE && lexeme_courant().nature != ACCF)
    {
      printf("enter CASE DEFAULT Rec_inst\n ");
      return 1;
    }
    break;
  }
}

int Rec_condition(Ast *Ag)
{
  // printf("Rec_condition(\n");
  Ast A1, A2;
  TypeBoolean OP;
  int err = 0;
  err = Rec_eag(&A1);
  // // printf(")\n");
  if (err == 1)
  {
    printf("Erreur in Rec_condition after Rec_eag 1 : \n");
    return 1;
  }
  err = Rec_opcomp(&OP);
  // // printf(")\n");

  if (err == 1)
  {
    printf("Erreur in Rec_codnition after Rec_opcomp : \n");
    return 1;
  }

  err = Rec_eag(&A2);
  // // printf(")\n");
  if (err == 1)
  {
    printf("Erreur in Rec_codnition after Rec_opcomp : \n");
    return 1;
  }

  switch (OP)
  {
  case B_EGALC:
    *Ag = creer_egal(A1, A2);
    // printf(" I CREATE EQUAL CONDITION");
    break;
  case B_SUPC:
    *Ag = creer_sup(A1, A2);
    //  printf(" I CREATE SUP CONDITION");
    break;
  case B_INFC:
    *Ag = creer_inf(A1, A2);
    //  printf(" I CREATE INF CONDITION");
    break;
  case B_INFEGALC:
    *Ag = creer_infegal(A1, A2);
    //  printf(" I CREATE INFEQUAL CONDITION");
    break;
  case B_NOTEGALC:
    *Ag = creer_notegal(A1, A2);
    //  printf(" I CREATE NOTEQUAL CONDITION");
    break;
  case B_SUPEGALC:
    *Ag = creer_supegal(A1, A2);
    //  printf(" I CREATE SUPEQUAL CONDITION");
    break;

  default:
    break;
  }
  return 0;
}

int Rec_opcomp(TypeBoolean *Op)
{
  // printf("rEC_OPCOMP (\n");
  // // afficher(lexeme_courant());
  switch (lexeme_courant().nature)
  {
  case SUP:
    *Op = B_SUPC;
    avancer();
    if (lexeme_courant().nature == EGAL)
    {
      *Op = B_SUPEGALC;
      avancer();
    }
    break;
  case EGAL:
    avancer();
    if (lexeme_courant().nature == EGAL)
    {
      *Op = B_EGALC;
      avancer();
    }
    break;
  case INF:
    *Op = B_INFC;
    avancer();
    if (lexeme_courant().nature == EGAL)
    {
      *Op = B_INFEGALC;
      avancer();
    }
    else
    {
      if (lexeme_courant().nature == SUP)
      {
        *Op = B_NOTEGALC;
        avancer();
      }
    }
    break;

  default:
    return 1;
    break;
  }
}