#include <string.h>
#include <stdio.h>
#include "table_symboles.h"
#include <stdlib.h>

void init_table()
{
    for (int i = 0; i < MAXSIZE; i++)
    {
        table[i] = NULL;
    }

    // printf("°°°°°Table initialized successfully! °°°\n");
}
int field_IsIn(char *name)
{

    for (int i = 0; i < MAXSIZE; i++)
    {
        if (table[i] != NULL && strcmp(table[i]->name, name) == 0)
            return 0;
    }
    return 1;
}
void insert_field(char *idf, int val)
{

    if (field_IsIn(idf) != 0)
    { // si l'identifiant n'existait pas on le rajoute
        field *camp = malloc(sizeof(field));
        strcpy(camp->name, idf);
        camp->value = val;

        for (int i = 0; i < MAXSIZE; i++)
        {
            if (table[i] == NULL)
            {
                table[i] = camp;
                return;
            }
        }
    }
    else // sinon on met à jour sa valeur
    {
        int i = indexOfField(idf); // return its existing index in table then assign to it its new value
        if (i != -1)
        {
            table[i]->value = val;
           
        }
    }
};

int search_value(char *name)
{
 int index=indexOfField(name);
 if (index!=-1){
    return table[index]->value;
 }
    
};

int indexOfField(char *name)
{
    if (field_IsIn(name) == 0)
    {
        for (int i = 0; i < MAXSIZE; i++)
        {
            if (table[i] != NULL && strcmp(table[i]->name, name) == 0)
                return i;
        }
    }

    // if fields doesn't exist return -1
    return -1;
}

void print_table()
{
    printf("\n");
    printf("°°°°° TABLES DES SYMBOLES°°°°°\n");
    int i = 0;
    while (table[i] != NULL && i < MAXSIZE)
    {

        printf("%s = %d\n", table[i]->name, table[i]->value);
        i++;
    }

    printf("°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°\n");
};

void free_table()
{

    for (int i = 0; i < MAXSIZE; i++)
    {
        if (table[i] == NULL)
            break;

        free(table[i]);
    }
}
