#include <stdio.h>
#include "type_ast.h"
#include <string.h>
#include "ast_parcours.h"
#include "table_symboles.h"

void aff_operateur(TypeOperateur op)
{
	switch (op)
	{
	case N_PLUS:
		printf("+");
		break;
	case N_MOINS:
		printf("-");
		break;
	case N_MUL:
		printf("*");
		break;
	case N_DIV:
		printf("/");
		break;
	}
}

void AfficherAST(Ast expr)
{
	switch (expr->nature)
	{
	case OPERATION:
		printf("(");
		AfficherAST(expr->gauche);
		aff_operateur(expr->operateur);
		AfficherAST(expr->droite);
		printf(")");
		break;
	case VALEUR:
		printf("%d", expr->valeur);
		break;

	case N_IDF:
		printf("%s", expr->idf);

		break;
	case N_EGAL:
		// printf("(");
		AfficherAST(expr->gauche);
		printf("=");
		AfficherAST(expr->droite);
		// printf(")");
		break;
	case N_PRINTF:
		printf("printf(");
		AfficherAST(expr->gauche);
		printf(")");
		break;
	case N_SCANF:
		printf("scanf(");
		AfficherAST(expr->gauche);
		printf(")");
		break;
	case N_PVIRG:
		AfficherAST(expr->gauche);
		printf(";\n");
		if (expr->droite != NULL)
			AfficherAST(expr->droite);
		break;

	case N_IF:
		printf("if (");
		AfficherAST(expr->gauche);
		printf(") then {\n");
		AfficherAST(expr->central);
		printf("}\n");
		if (expr->droite != NULL)
			{printf(" else {\n");
			AfficherAST(expr->droite);
			printf("}");}
		printf("\n");
		break;

	case N_SUP:
		AfficherAST(expr->gauche);
		printf(">");
		AfficherAST(expr->droite);
		break;
	case N_INF:
		AfficherAST(expr->gauche);
		printf("<");
		AfficherAST(expr->droite);
		break;
	case N_EGALCOND:
		AfficherAST(expr->gauche);
		printf("==");
		AfficherAST(expr->droite);
		break;
	
	case N_SUPEGAL:
		AfficherAST(expr->gauche);
		printf(">=");
		AfficherAST(expr->droite);
		break;
	case N_INFEGAL:
		AfficherAST(expr->gauche);
		printf("<=");
		AfficherAST(expr->droite);
		break;
	case N_NOTEGAL:
		AfficherAST(expr->gauche);
		printf("<>");
		AfficherAST(expr->droite);
		break;
	case N_WHILE:
		printf("while (");
		AfficherAST(expr->gauche);
		printf("){\n");
		AfficherAST(expr->droite);
		printf("}\n");
		break;
	case N_FOR:
		printf("for(");
		AfficherAST(expr->gauche);
		printf(";");
		AfficherAST((expr->droite)->gauche);
		printf(";");
		AfficherAST(((expr->droite)->droite)->droite);
		printf("){\n");
		AfficherAST(((expr->droite)->droite)->gauche);
		printf("}\n");
		break;
	
	default:

		break;
	}
}

int evaluation(Ast expr)
{
	int vg, vd;
	switch (expr->nature)
	{
	case VALEUR:
		return expr->valeur;
		break;
	case OPERATION:
		vg = evaluation(expr->gauche);
		vd = evaluation(expr->droite);
		switch (expr->operateur)
		{
		case N_PLUS:
			return vg + vd;
			break;
		case N_MOINS:
			return vg - vd;
			break;
		case N_MUL:
			return vg * vd;
			break;
		case N_DIV:
			if (vd == 0)
			{
				printf("Attention Division par ZÉRO !!");
				return -1;
			}
			return vg / vd;
			break;

		default:
			break;
		}
	case N_IDF:
		return search_value(expr->idf);
		break;
	default:
		break;
	}
	return -1;
}

void interpreter_affectation(Ast A)
{
	char name[128];
	int value;
	strcpy(name, (A->gauche)->idf);

	value = evaluation(A->droite);
	// printf("name= %s,value=%d \n", name, value);
	insert_field(name, value);
}
void interpreter_ecrire(Ast A)
{
	int value = evaluation(A->gauche);
	printf("%d\n", value);
}
void interpreter_lire(Ast A)
{
	int value;
	printf("ENTER NUMBER :");
	scanf("%d", &value);
	insert_field((A->gauche)->idf, value);
}


void interpreter_if(Ast A){
	int value=evaluer_condition(A->gauche);
	if(value!=0){
		interpreter(A->central);
	}
	else{
		if(A->droite!=NULL)
			interpreter(A->droite);
	}

}

int evaluer_condition(Ast A){
	int g=evaluation(A->gauche);
	int d=evaluation(A->droite);

	switch (A->nature)
	{
	case N_INF:
		return g<d;
		break;
	case N_SUP:
		return g>d;
		break;
	case N_EGALCOND:
		return g==d;
		break;
	case N_SUPEGAL:
		return g>=d;
		break;
	case N_INFEGAL:
		return g<=d;
		break;
	case N_NOTEGAL:
		return g!=d;
		break;
	default:
		break;
	}
}

void interpretation_finale(Ast A){
	init_table();
	interpreter(A);
}

void interpreter_while(Ast A){
	int condValue=evaluer_condition(A->gauche);
	while(condValue==1){
		interpreter(A->droite);
		condValue=evaluer_condition(A->gauche);
	}
}
void interpreter_for(Ast A){
	interpreter_affectation(A->gauche);
	interpreter_while(A->droite);
}
int interpreter(Ast A)
{
	
	switch (A->nature)
	{
	case N_PVIRG:
		// printf("N_PVIRG\n");
		interpreter(A->gauche);
		interpreter(A->droite);
		break;
	case N_EGAL:
		// printf("N_EGAL\n");
		interpreter_affectation(A);
		break;
	case N_PRINTF:
		// printf("N_PRINTF\n");
		interpreter_ecrire(A);
		break;
	case N_SCANF:
		// printf("N_SCANF\n");
		interpreter_lire(A);
		break;
	case N_IF:
		// printf("N_IF\n");
		interpreter_if(A);
		break;
	case N_WHILE:
		// printf("N_WHILE\n");
		interpreter_while(A);
		break;
	case N_FOR:
		// printf("N_FOR\n");
		interpreter_for(A);
		break;
	default:
		// printf("ERROR d\'interpretation dans default\n");
		return 1;
		break;
	}


	return 0;
}

